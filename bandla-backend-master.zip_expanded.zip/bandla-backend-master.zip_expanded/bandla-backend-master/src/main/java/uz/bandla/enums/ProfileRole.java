package uz.bandla.enums;

public enum ProfileRole {
    USER, MANAGER, ADMIN, SYSTEM_ADMIN
}