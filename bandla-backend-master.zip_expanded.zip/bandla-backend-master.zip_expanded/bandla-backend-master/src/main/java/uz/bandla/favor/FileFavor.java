package uz.bandla.favor;

import uz.bandla.entity.FileEntity;

public interface FileFavor {
    void save(FileEntity entity);
}