package uz.bandla.component;

import org.springframework.stereotype.Component;

@Component
public class SmsSender {

    public void sendAsync(String phoneNumber, String message) {

    }
}
