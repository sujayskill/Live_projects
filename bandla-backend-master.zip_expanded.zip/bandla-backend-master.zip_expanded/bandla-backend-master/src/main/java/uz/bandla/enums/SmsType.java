package uz.bandla.enums;

public enum SmsType {
    VERIFICATION
}
