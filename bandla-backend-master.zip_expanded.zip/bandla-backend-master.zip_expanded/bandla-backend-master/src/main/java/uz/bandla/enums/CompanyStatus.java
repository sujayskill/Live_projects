package uz.bandla.enums;

public enum CompanyStatus {
    CREATED, CONFIRMED, ACTIVE, BLOCKED
}