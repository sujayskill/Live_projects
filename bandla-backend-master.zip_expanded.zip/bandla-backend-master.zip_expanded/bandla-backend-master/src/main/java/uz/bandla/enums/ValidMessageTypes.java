package uz.bandla.enums;

public enum ValidMessageTypes {
    LENGTH, LOWERCASE, UPPERCASE, DIGIT
}
