package uz.bandla.dto.file;

public record FileDTO(String id, String url) {
}