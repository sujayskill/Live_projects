package uz.bandla.enums;

public enum ProfileStatus {
    NOT_VERIFIED, ACTIVE, BLOCKED
}
