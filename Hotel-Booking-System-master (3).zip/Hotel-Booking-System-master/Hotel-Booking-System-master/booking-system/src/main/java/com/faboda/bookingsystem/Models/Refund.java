package com.faboda.bookingsystem.Models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "refund")
public class Refund {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Integer id;

	@Column(name = "amount", nullable = false)
	private Integer amount;

	@OneToOne(orphanRemoval = false)
	@JoinColumn(name = "booking_id")
	private Booking booking;

}