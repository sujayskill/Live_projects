package com.faboda.bookingsystem.Configurations;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AwsConfig {

//    @Value("${s3.key.id}")
//    private String accessKeyId;
//
//    @Value("${s3.key.secret}")
//    private String accessKeySecret;
//
//    @Value("${s3.region.name}")
//    private String s3RegionName;

//    @Bean
//    public AmazonS3 getAmazonS3Client() {
//        final BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(accessKeyId, accessKeySecret);
//
//        System.out.println(basicAWSCredentials.toString());
//
//        AmazonS3 s3Object = AmazonS3ClientBuilder
//                .standard()
//                .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
//                .withRegion(s3RegionName)
//                .build();
//
//
//        return  s3Object;
//
//
//    }

}