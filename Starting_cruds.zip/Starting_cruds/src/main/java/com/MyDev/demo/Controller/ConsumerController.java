package com.MyDev.demo.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.MyDev.demo.Service.Consumer;
import com.MyDev.demo.Service.ServerVerification;

@RestController
@RequestMapping("/kafkaConsumer")
public class ConsumerController {

	@Autowired
	private Consumer kafkaConsumer;
	
	@Autowired
	private ServerVerification serverVerification;

//	@GetMapping("/reqDateAndTime")
//	public List<Map<String, String>> requestDeteAndTime() {
//		return kafkaConsumer.returnTwoString();
//	}
//
//	@GetMapping("/messages")
//	public List<String> getMessages() {
//		return kafkaConsumer.getMessages();
//	}
	
	@GetMapping("/getPlaneServerInfo")
	public String getServerInformation()
	{
		String getInfo = serverVerification.getPlaneServerStatus();
		return getInfo;
	}
	
	@GetMapping("/getServerInfo")
	public String getPortInformation()
	{
		String getInfo = serverVerification.getServerStatus();
		return getInfo;
	}
	
	
	
	
}
