package com.MyDev.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MyDev.demo.Entity.EntityModel;

public interface EntityRepository extends JpaRepository<EntityModel, Long> {


}