package com.MyDev.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MyDev.demo.Entity.EntityModel;
import com.MyDev.demo.Repository.EntityRepository;

import java.util.List;

@Service
public class EntityService {
    @Autowired
    private EntityRepository repository;

    public List<EntityModel> getAllEntities() {
        return repository.findAll();
    }

    public EntityModel getEntityById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public EntityModel saveEntity(EntityModel entity) {
        return repository.save(entity);
    }

    public void deleteEntity(Long id) {
        repository.deleteById(id);
    }
}
