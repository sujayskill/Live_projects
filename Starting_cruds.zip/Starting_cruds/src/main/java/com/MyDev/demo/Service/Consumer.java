package com.MyDev.demo.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class Consumer {


	   @Autowired
	    private KafkaTemplate<String, String> kafkaTemplate;

	    private static final String RESPONSE_TOPIC = "response_topic";

	    @KafkaListener(topics = "request_topic", groupId = "consumer_group")
	    public void consume(String message) throws Exception {
	        ObjectMapper objectMapper = new ObjectMapper();
	        Map<String, String> messageMap = objectMapper.readValue(message, Map.class);
	        String messageId = messageMap.get("messageId");
	        String requestMessage = messageMap.get("message");

	        // Process the message and determine if it's accepted or denied
	        String response = processMessage(requestMessage);

	        // Send the response
	        Map<String, String> responseMap = new HashMap<>();
	        responseMap.put("messageId", messageId);
	        responseMap.put("response", response);
	        String responseMessage = objectMapper.writeValueAsString(responseMap);

	        kafkaTemplate.send(RESPONSE_TOPIC, responseMessage);
	    }

	    private String processMessage(String message) {
	        // Add your business logic here
	        // For example, accept if the message contains "accept", deny otherwise
	        if (message.contains("accept")) {
	            return "accepted";
	        } else {
	            return "denied";
	        }
	    }
	
	
	
//	private final List<String> oneString = new ArrayList<>();
//
//	private final List<Map<String, String>> twoString = new ArrayList<>();
//
//	private static final String RESPONSE_TOPIC = "response_topic";

//	public List<Map<String, String>> returnTwoString() {
//		return twoString;
//	}
//
//	public List<String> getMessages() {
//		return oneString;
//	}
//	@KafkaListener(topics = "example_topic", groupId = "group_id")
//	public void consumeSample(String message) {
//		System.out.println("Consumed message: " + message);
//		oneString.add(message);
//	}
	
	
	
	
//	@KafkaListener(topics = "currentDateAndTime", groupId = "group_id")
//	public void consumeCurrentDateAndTime(String message) {
//
//		try {
//			ObjectMapper objectMapper = new ObjectMapper();
//			Map<String, String> messageMap = objectMapper.readValue(message, Map.class);
////            System.out.println("Received message: " + messageMap);
//			System.out.println("Consumed message: " + messageMap);
//			twoString.add(messageMap);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
}
