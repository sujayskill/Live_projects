package com.MyDev.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartingCrudsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StartingCrudsApplication.class, args);
	}

}
