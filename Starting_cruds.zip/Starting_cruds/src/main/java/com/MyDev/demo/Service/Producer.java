package com.MyDev.demo.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class Producer {

	private static final String REQUEST_TOPIC = "request_topic";

	private static final String RESPONSE_TOPIC = "response_topic";

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	private final Map<String, CompletableFuture<String>> responseFutures = new ConcurrentHashMap<>();

	public String sendMessage(String message) throws Exception {
		String messageId = String.valueOf(System.currentTimeMillis());
		String currentTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		Map<String, String> messageMap = new HashMap<>();
		messageMap.put("messageId", messageId);
		messageMap.put("message", message);
		messageMap.put("timestamp", currentTime);

		ObjectMapper objectMapper = new ObjectMapper();
		String messageWithTimestamp = objectMapper.writeValueAsString(messageMap);

		CompletableFuture<String> responseFuture = new CompletableFuture<>();
		responseFutures.put(messageId, responseFuture);

		kafkaTemplate.send(REQUEST_TOPIC, messageWithTimestamp);

		// Wait for the response for a maximum of 30 seconds
		return responseFuture.get(30, TimeUnit.SECONDS);
	}

	@KafkaListener(topics = RESPONSE_TOPIC, groupId = "producer_group")
	public void listenResponse(String message) throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, String> messageMap = objectMapper.readValue(message, Map.class);
		String messageId = messageMap.get("messageId");
		String response = messageMap.get("response");

		CompletableFuture<String> responseFuture = responseFutures.get(messageId);
		if (responseFuture != null) {
			responseFuture.complete(response);
			responseFutures.remove(messageId);
		}
	}

}

//public void sendMessage(String message) {
//kafkaTemplate.send(TOPIC, message);
//}

//private static final String TOPIC = "example_topic";
//
//	private static final String TOPIC1 = "currentDateAndTime";
