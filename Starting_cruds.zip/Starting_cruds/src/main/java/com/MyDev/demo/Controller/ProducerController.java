package com.MyDev.demo.Controller;

import java.security.Principal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.MyDev.demo.Service.Producer;

@RestController
@RequestMapping("/kafkaProducer")
public class ProducerController {

	@Autowired
	private Producer kafkaProducer;

//	@GetMapping("/publish")
//	public String publishMessage(@RequestParam("message") String message) {
//		kafkaProducer.sendMessage(message);
//		return "Message published successfully";
//	}

//	@PostMapping("/publishDateAndTime")
//	public String prodcueDateAndTime(@RequestBody Map<String, String> message) {
//		kafkaProducer.dateAndTimeProducer(message.get("message"));
//		return "Message published successfully";
//	}

//	@PostMapping("/publish")
//    public String publishMessage(@RequestBody Map<String, String> message) {
//        return kafkaProducer.requestProducer(message.get("message"));
//    }

	@PostMapping("/publish")
	public String publishMessage(@RequestBody Map<String, String> message) {
		try {
			String response = kafkaProducer.sendMessage(message.get("message"));
			return "Message response: " + response;
		} catch (Exception e) {
			e.printStackTrace();
			return "Error publishing message";
		}
	}
	
	@GetMapping("/hello")
    public String hello(Principal principal) {
        return "Hello, " + principal.getName();
    }
	
	
	
	
	
}
