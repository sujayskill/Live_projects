package com.MyDev.demo;

public class Interview {

//	10 -> 6 
//	
//	1,2,3,4,5,6,7,8,9,0
//	
//	
	public static void main(String[] args) {

//		int arr[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
//		int key = 6;
//		int start = 0;
//		int len = arr.length;
//		int mid = start + len / 2;
////		System.out.println(mid+" "+len);
////		System.out.println(arr[start]);
//
//		for (int i = 0; i < arr.length; i++) {
//			if (key == mid) {
//				System.out.println("value found at " + mid);
//				break;
//			} else if (key > mid) {
////				for (int j = mid; j > arr.length; j++) {
//				if (arr[i] != key) {
//
//					mid++;
//				} else {
//					System.out.println("value found at >" + arr[i]);
//				}
//
//			} else {
////				for (int j = mid; j <= 0; j++) {
//				if (arr[i] != key) {
//					mid--;
//				} else {
//					System.out.println("value found at <" + arr[i]);
//
//				}
//			}
////			}
//		}

		int num = 9;
		int count = 0;
		for (int i = 1; i >=num; i++) {
			if (num%i == 0)
				count++;
		}

		if (count >2) {
			System.out.println("number is prime");
		} else {
			System.out.println("number is not prime");
		}

	}

}
