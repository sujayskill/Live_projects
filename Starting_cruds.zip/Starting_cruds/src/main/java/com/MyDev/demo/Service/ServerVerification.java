package com.MyDev.demo.Service;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;

@Service
public class ServerVerification {

	@Autowired
	private AdminClient adminClient;
	
	private String getPortInfo;

	@PostConstruct
	public String getServerStatus() {
		try {
			DescribeClusterResult describeClusterResult = adminClient.describeCluster();
			String brokerId = describeClusterResult.nodes().get().iterator().next().idString();
			String brokerAddress = describeClusterResult.nodes().get().iterator().next().host();
			int brokerPort = describeClusterResult.nodes().get().iterator().next().port();
//			System.out.println("Kafka is running on broker ID: " + brokerId);
//			System.out.println("Kafka broker address: " + brokerAddress + " on port: " + brokerPort);
			getPortInfo = "Kafka broker address: " + brokerAddress + " on port: " + brokerPort;
			return getPortInfo;
		} catch (ExecutionException | InterruptedException e) {
//			System.out.println("Kafka is not running.");
			getPortInfo = "Kafka is not running.";
			return getPortInfo;
		}
	}

	public String getPlaneServerStatus() {
		Properties props = new Properties();
		props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");

		try (AdminClient client = AdminClient.create(props)) {
			client.listTopics().names().get();

//			System.out.println("Kafka server is running");
			return "Kafka server is running";
		} catch (ExecutionException | InterruptedException e) {
//			System.out.println("Kafka server is not running");
			return "Kafka server is not running";
		}
	}

}
