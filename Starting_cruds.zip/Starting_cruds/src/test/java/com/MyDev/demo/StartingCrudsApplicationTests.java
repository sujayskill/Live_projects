package com.MyDev.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartingCrudsApplicationTests {

	@Test
	void contextLoads() {
	}

}
